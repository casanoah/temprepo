#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"
#include "filesys/filesys.h"
#include "userprog/pagedir.h"
#include "devices/shutdown.h"
#include "user/syscall.h"
#include "threads/malloc.h"
#include "userprog/process.h"
#include "devices/input.h"
#include "filesys/file.h"


/*most function definitions taken from pintos document 
provided on piazza*/
static void syscall_handler (struct intr_frame *);
int write(int fd, const void* buffer, unsigned size);
void exit (int status);
bool create (const char* file, unsigned initial_size);
void halt(void);
int wait(pid_t pid);
void checkptr(const void* vaddr);
bool remove(const char* file);
int open(const char* file);
int read(int fd, void* buffer, unsigned size);
struct file* get_file(int fd);
void seek(int fd, unsigned position);
unsigned tell(int fd);
int filesize(int fd);
tid_t exec(const char* cmd_line);
void close(int fd);

struct lock syslock;

/*file_info struct used for 
  keeping track of open 
  files and file descriptor*/
struct file_info {
  int fd;
  struct file* fileptr;
  struct list_elem filelist_elem;
};

void
syscall_init (void) 
{
  lock_init(&syslock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{

	if (!is_user_vaddr(f->esp) || f->esp < ((void*) 0x08048000))
    {
      exit(-1);
    }

  int fd;
  int *ptr;
  int* ptr2;
  int* ptr3;
  void* temp;

  switch(*(int*)f->esp){
  	//copied write here from stephen's doc in the coursework folder
  	case SYS_WRITE:

	  	fd = *((int*)f->esp + 1);
		  void* buffer = (void*)(*((int*)f->esp + 2));
		  unsigned size = *((unsigned*)f->esp + 3);
      temp = pagedir_get_page(thread_current()->pagedir, (const void*) buffer);
      if (!temp) {
        exit (-1);
      }
		  //run the syscall, a function of your own making
		  //since this syscall returns a value, the return value should be stored in f->eax
		  f->eax = write(fd, buffer, size);
      if (f->eax == (unsigned)-1) 
      {
        exit(-1);
      }
  	break;

  	case SYS_EXIT:
  		ptr = (int *) f->esp + 1;
      checkptr((const void*) ptr);
  		exit(*ptr);
  	break;

    case SYS_HALT:
      halt();
    break;

    case SYS_CREATE:
      ptr = (int*)f->esp + 1;
      ptr2 = (int*) f->esp + 2;
      checkptr((const void*) ptr);
      checkptr((const void*) ptr2);
      temp = pagedir_get_page(thread_current()->pagedir, (const void*) *ptr);
      if (!temp) {
        exit (-1);
      }
      f->eax = create((const char*) temp, (unsigned) *ptr2);
    break;

    case SYS_REMOVE:
      ptr = (int*)f->esp +1;
      checkptr((const void*) ptr);
      temp = pagedir_get_page(thread_current()->pagedir, (const void*) *ptr);
      if (!temp) {
        exit (-1);
      }
      f->eax = remove((const char*) temp);
    break;

    case SYS_OPEN:
      ptr = (int*) f->esp + 1;
      checkptr((const void*) ptr);
      temp = pagedir_get_page(thread_current()->pagedir, (const void*) *ptr);
      if (!temp) {
        exit (-1);
      }
      f->eax = open((const char*) temp);
      if (f->eax == (unsigned)-1) {
        lock_release(&syslock);
      }
    break;

    case SYS_READ:
      ptr = (int*) f->esp + 1;
      ptr2 = (int*) f->esp + 2;
      ptr3 = (int *) f->esp + 3;
      checkptr((const void*) ptr);
      checkptr((const void*) ptr2);
      checkptr((const void*) ptr3);
      unsigned i = 0;
      char* buff = (char*) *ptr2;
      while (i<(unsigned)*ptr3) {
        checkptr((const void*) buff);
        buff++;
        i++;
      }
      temp = pagedir_get_page(thread_current()->pagedir, (const void*) *ptr2);
      if (!temp) 
      {
        exit(-1);
      } 
      f->eax = read(*ptr, (void *) temp, (unsigned) *ptr3);
      if (f->eax == (unsigned)-1)
      {
        lock_release(&syslock);
      }
    break;

    case SYS_SEEK:
      ptr = (int*) f->esp + 1;
      ptr2 = (int*) f->esp + 2;
      checkptr((const void*) ptr);
      checkptr((const void*) ptr2);
      seek(*ptr, (unsigned) *ptr2);
    break;

    case SYS_TELL:
      ptr = (int*) f->esp + 1;
      checkptr((const void*) ptr);
      f->eax = tell(*ptr);
    break;

    case SYS_FILESIZE:
      ptr = (int*) f->esp + 1;
      checkptr((const void*) ptr);
      f->eax = filesize(*ptr);
    break;

    case SYS_EXEC:
      ptr = (int*) f->esp + 1;
      checkptr((const void*) ptr);
      temp = pagedir_get_page(thread_current()->pagedir, (const void*) *ptr);
      if (!temp) 
      {
        exit(-1);
      }
      f->eax = exec(temp);
    break;

    case SYS_WAIT:
      ptr = (int*) f->esp + 1;
      checkptr((const void*) ptr);
      //temp = pagedir_get_page(thread_current()->pagedir, (const void*) *ptr);
      f->eax = wait(*ptr);
    break;

  }

}

int 
filesize(int fd)
{
  //synch
  lock_acquire(&syslock);
  struct file* file;
  file = get_file(fd);
  //easy call already defined in file
  int size; 
  size = file_length(file);
  lock_release(&syslock);
  return size;
}

void 
seek(int fd, unsigned position)
{
  //synch
  lock_acquire(&syslock);
  struct file* file;
  file = get_file(fd);
  file_seek(file, position);
  lock_release(&syslock);
}

unsigned 
tell(int fd) 
{
  //synch
  lock_acquire(&syslock);
  struct file* file;
  file = get_file(fd);
  unsigned nextpos;
  nextpos = file_tell(file);
  lock_release(&syslock);
  return nextpos;
}

int 
write(int fd, const void* buffer, unsigned size){
  if (fd != 1) {
    //valid file
    lock_acquire(&syslock);
    struct file* file;
    file = get_file(fd);
    if (!file) {
      return -1;
    }
    int bytes;
    bytes = file_write(file, buffer, size);
    lock_release(&syslock);
    return bytes;
  }
  putbuf(buffer, size);
  return size;
}

void 
exit (int status)
{
  struct thread *cur = thread_current();
  printf ("%s: exit(%d)\n", cur->name, status);
  if (thread_exists(cur->parent))
  {
    cur->cn->status = status;
  }
  thread_exit();
}

void
halt (void) 
{
  shutdown_power_off();
}

int 
wait (pid_t pid) 
{
  return process_wait(pid);
}

bool 
create (const char* file, unsigned initial_size)
{
  lock_acquire(&syslock);
  bool success = filesys_create(file, initial_size);
  lock_release(&syslock);
  return success;
}

bool 
remove (const char* file)
{
  lock_acquire(&syslock);
  bool success = filesys_remove(file);
  lock_release(&syslock);
  return success;
}

int 
open(const char* file) 
{
  lock_acquire(&syslock);
  struct file* mfile;
  mfile = filesys_open(file);
  thread_current()->filedesc++;
  struct file_info *pf;
  pf = malloc(sizeof(struct file_info));
  pf->fd = thread_current()->filedesc-1;
  if (!mfile) {
    return -1;
  }
  pf->fileptr = mfile;
  list_push_back(&thread_current()->files, &pf->filelist_elem);
  lock_release(&syslock);
  return pf->fd;
}

int 
read(int fd, void* buffer, unsigned size)
{
  if (fd != 0) {
    lock_acquire(&syslock);
    struct file* file;
    file = get_file(fd);
    if (!file) {
      return -1;
    }
    int bytes;
    bytes = file_read(file, buffer, size);
    lock_release(&syslock);
    return bytes;
  }
  return size;
}


/*get file with file descriptor from list of files from current
  thread, needed for file access sys calls*/
struct file* 
get_file(int fd)
{
  struct list_elem* e = list_begin(&thread_current()->files);
  while (e != list_end(&thread_current()->files))
  {
    struct file_info *info = list_entry(e, struct file_info, filelist_elem);
    if (fd == info->fd) {
      return info->fileptr;
    }
    e = list_next(e);
  }
  return NULL;
}

/*check if pointer is a valid address*/
void checkptr(const void* vaddr)
{
  if (!is_user_vaddr(vaddr))
  {
    exit(-1);
  }
}

tid_t exec(const char* cmd_line){

  tid_t pid = process_execute(cmd_line);
  /*while child has not successfully loaded, current process
    waits until the child has finished loading. if child fails
    exit*/
  struct childNode *cn = getChildNodeWithTID(pid);
  while (cn->load_success == 0) 
  {
    barrier();
  }
  if (cn->load_success == 2) {
    pid = -1;
  }
  return pid;
}